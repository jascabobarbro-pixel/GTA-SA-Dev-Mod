# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in the Android SDK.

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep crash handler
-keep class com.gtasa.devmod.crash.** { *; }

# Keep mod loader classes
-keep class com.gtasa.devmod.modloader.** { *; }

# Keep JNI interface classes
-keep class com.gtasa.devmod.nativebridge.** { *; }
