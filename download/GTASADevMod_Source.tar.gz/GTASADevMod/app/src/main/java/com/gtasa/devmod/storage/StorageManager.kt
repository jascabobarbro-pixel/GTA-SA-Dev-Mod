package com.gtasa.devmod.storage

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Storage Manager for Android 15+ Compatibility
 * 
 * This class handles all file I/O operations with proper scoped storage compliance
 * while maintaining support for the unprotected /sdcard/GTA_SA_Dev/ working directory.
 * 
 * Features:
 * - MANAGE_EXTERNAL_STORAGE permission management for Android 11+
 * - Unprotected directory support at /sdcard/GTA_SA_Dev/
 * - TXD/DFF file reading from public directories
 * - Automatic permission request handling
 */
object StorageManager {
    
    private const val TAG = "StorageManager"
    
    // Public working directory (no scoped storage restrictions)
    const val PUBLIC_WORKING_DIR = "GTA_SA_Dev"
    
    // Subdirectories for different mod types
    const val TEXTURES_DIR = "textures"
    const val MODELS_DIR = "models"
    const val CLEO_DIR = "cleo"
    const val CONFIG_DIR = "configs"
    const val LOGS_DIR = "logs"
    const val BACKUP_DIR = "backups"
    
    private lateinit var appContext: Context
    private var workingDirectory: File? = null
    private var logDirectory: File? = null
    private var hasAllFilesAccess = false
    
    /**
     * Initialize the storage manager
     */
    fun initialize(context: Context) {
        appContext = context.applicationContext
        
        // Check and request permissions
        checkStoragePermissions()
        
        // Setup working directory
        setupWorkingDirectory()
        
        Log.i(TAG, "Storage manager initialized. Working dir: ${workingDirectory?.absolutePath}")
    }
    
    /**
     * Check storage permissions based on Android version
     */
    private fun checkStoragePermissions() {
        hasAllFilesAccess = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ requires MANAGE_EXTERNAL_STORAGE for full access
            Environment.isExternalStorageManager()
        } else {
            // Android 10 and below
            val readGranted = ContextCompat.checkSelfPermission(
                appContext, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            
            val writeGranted = ContextCompat.checkSelfPermission(
                appContext, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            
            readGranted && writeGranted
        }
        
        Log.i(TAG, "All files access: $hasAllFilesAccess")
    }
    
    /**
     * Check if we have all files access permission
     */
    fun hasAllFilesAccessPermission(): Boolean = hasAllFilesAccess
    
    /**
     * Request MANAGE_EXTERNAL_STORAGE permission for Android 11+
     * This must be called from an Activity
     */
    fun requestAllFilesAccess(activity: Activity, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:${appContext.packageName}")
                    }
                    activity.startActivityForResult(intent, requestCode)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to open all files access settings: ${e.message}")
                    // Fallback to general settings
                    val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    activity.startActivityForResult(intent, requestCode)
                }
            }
        }
    }
    
    /**
     * Setup the working directory at /sdcard/GTA_SA_Dev/
     * This is a public directory that doesn't require scoped storage permissions
     */
    private fun setupWorkingDirectory() {
        // Primary location: /sdcard/GTA_SA_Dev/
        val externalStorage = Environment.getExternalStorageDirectory()
        workingDirectory = File(externalStorage, PUBLIC_WORKING_DIR)
        
        // Create main directory
        if (!workingDirectory!!.exists()) {
            val created = workingDirectory!!.mkdirs()
            Log.i(TAG, "Working directory created: ${workingDirectory!!.absolutePath} ($created)")
        }
        
        // Create subdirectories
        createSubdirectories()
        
        // Setup log directory
        logDirectory = File(workingDirectory, LOGS_DIR)
        if (!logDirectory!!.exists()) {
            logDirectory!!.mkdirs()
        }
        
        // Create .nomedia to prevent media scanning
        File(workingDirectory, ".nomedia").apply {
            if (!exists()) createNewFile()
        }
    }
    
    /**
     * Create standard subdirectories for mod organization
     */
    private fun createSubdirectories() {
        val subdirs = listOf(
            TEXTURES_DIR,
            MODELS_DIR,
            CLEO_DIR,
            CONFIG_DIR,
            LOGS_DIR,
            BACKUP_DIR
        )
        
        subdirs.forEach { subdir ->
            val dir = File(workingDirectory, subdir)
            if (!dir.exists()) {
                dir.mkdirs()
                Log.d(TAG, "Created subdirectory: $subdir")
            }
        }
    }
    
    /**
     * Get the main working directory
     */
    fun getWorkingDirectory(): String = workingDirectory?.absolutePath ?: ""
    
    /**
     * Get the log directory
     */
    fun getLogDirectory(): String = logDirectory?.absolutePath ?: ""
    
    /**
     * Get textures directory
     */
    fun getTexturesDirectory(): File = File(workingDirectory, TEXTURES_DIR)
    
    /**
     * Get models directory
     */
    fun getModelsDirectory(): File = File(workingDirectory, MODELS_DIR)
    
    /**
     * Get CLEO scripts directory
     */
    fun getCleoDirectory(): File = File(workingDirectory, CLEO_DIR)
    
    /**
     * Get config directory
     */
    fun getConfigDirectory(): File = File(workingDirectory, CONFIG_DIR)
    
    /**
     * Get backup directory
     */
    fun getBackupDirectory(): File = File(workingDirectory, BACKUP_DIR)
    
    /**
     * Check if a file is accessible
     */
    fun isFileAccessible(file: File): Boolean {
        return try {
            file.exists() && file.canRead()
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Check if we can write to a directory
     */
    fun canWriteToDirectory(dir: File): Boolean {
        return try {
            val testFile = File(dir, ".test_write")
            val canWrite = testFile.createNewFile()
            if (canWrite) {
                testFile.delete()
            }
            canWrite
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Get storage info
     */
    fun getStorageInfo(): StorageInfo {
        val stat = android.os.StatFs(workingDirectory?.absolutePath ?: "/sdcard")
        
        return StorageInfo(
            totalSpace = stat.totalBytes,
            freeSpace = stat.availableBytes,
            usableSpace = stat.availableBytes,
            hasAllFilesAccess = hasAllFilesAccess
        )
    }
    
    /**
     * Create a backup of a file
     */
    fun createBackup(file: File): File? {
        if (!file.exists()) return null
        
        val backupDir = getBackupDirectory()
        val timestamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
            .format(java.util.Date())
        val backupFile = File(backupDir, "${file.name}.$timestamp.bak")
        
        return try {
            file.copyTo(backupFile, overwrite = true)
            Log.i(TAG, "Created backup: ${backupFile.absolutePath}")
            backupFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create backup: ${e.message}")
            null
        }
    }
    
    /**
     * Storage information data class
     */
    data class StorageInfo(
        val totalSpace: Long,
        val freeSpace: Long,
        val usableSpace: Long,
        val hasAllFilesAccess: Boolean
    ) {
        val totalSpaceMB: Long get() = totalSpace / (1024 * 1024)
        val freeSpaceMB: Long get() = freeSpace / (1024 * 1024)
        val usedSpaceMB: Long get() = (totalSpace - freeSpace) / (1024 * 1024)
    }
}
