package com.gtasa.devmod.crash

import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.gtasa.devmod.R
import com.gtasa.devmod.databinding.ActivityCrashReportBinding
import java.io.File

/**
 * Crash Report Activity
 * 
 * Displays crash log details when the app is launched after a crash.
 */
class CrashReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCrashReportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCrashReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        // Get crash log path from intent
        val crashLogPath = intent.getStringExtra("crash_log_path")
        
        if (crashLogPath != null) {
            loadCrashLog(File(crashLogPath))
        } else {
            binding.tvCrashLog.text = "No crash log available"
        }
    }
    
    private fun loadCrashLog(file: File) {
        try {
            val content = file.readText()
            binding.tvCrashLog.text = content
        } catch (e: Exception) {
            binding.tvCrashLog.text = "Failed to read crash log: ${e.message}"
        }
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
