package com.gtasa.devmod.utils

import android.content.Context
import android.os.Build
import android.util.Log

/**
 * CPU Architecture Auto-Detection Utility
 * 
 * This utility class automatically detects the device's CPU architecture
 * and selects the appropriate native library directory.
 * 
 * Supports:
 * - ARM64 (arm64-v8a)
 * - ARMv7 (armeabi-v7a)
 * - x86 (x86)
 * - x86_64 (x86_64)
 */
object ArchitectureDetector {
    
    private const val TAG = "ArchitectureDetector"
    
    // Architecture constants
    const val ARCH_ARM64 = "arm64-v8a"
    const val ARCH_ARMV7 = "armeabi-v7a"
    const val ARCH_X86 = "x86"
    const val ARCH_X86_64 = "x86_64"
    
    // ABI to architecture mapping
    private val abiToArch = mapOf(
        "arm64-v8a" to "ARM64",
        "armeabi-v7a" to "ARMv7",
        "armeabi" to "ARM",
        "x86_64" to "x86_64",
        "x86" to "x86",
        "mips64" to "MIPS64",
        "mips" to "MIPS"
    )
    
    /**
     * Detect the device's CPU architecture
     */
    fun detectArchitecture(context: Context): ArchitectureInfo {
        val supportedAbis = Build.SUPPORTED_ABIS
        val primaryAbi = supportedAbis.firstOrNull() ?: "unknown"
        
        val archName = abiToArch[primaryAbi] ?: "Unknown"
        val is64Bit = primaryAbi.contains("64")
        val isArm = primaryAbi.contains("arm", ignoreCase = true)
        val isX86 = primaryAbi.contains("x86", ignoreCase = true)
        
        Log.i(TAG, "Detected architecture: $archName ($primaryAbi)")
        Log.d(TAG, "Supported ABIs: ${supportedAbis.joinToString(", ")}")
        
        return ArchitectureInfo(
            primaryAbi = primaryAbi,
            supportedAbis = supportedAbis.toList(),
            architectureName = archName,
            is64Bit = is64Bit,
            isArm = isArm,
            isX86 = isX86,
            nativeLibDir = getNativeLibDirectory(context, primaryAbi)
        )
    }
    
    /**
     * Get the native library directory for the given ABI
     */
    private fun getNativeLibDirectory(context: Context, abi: String): String {
        return try {
            val nativeLibDir = context.applicationInfo.nativeLibraryDir
            
            // Check if the native library directory matches our ABI
            if (nativeLibDir.contains(abi)) {
                nativeLibDir
            } else {
                // Fallback to constructed path
                "${context.applicationInfo.sourceDir}/lib/$abi"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get native lib directory: ${e.message}")
            "/data/data/${context.packageName}/lib"
        }
    }
    
    /**
     * Check if the device supports a specific ABI
     */
    fun supportsAbi(abi: String): Boolean {
        return Build.SUPPORTED_ABIS.contains(abi)
    }
    
    /**
     * Get the recommended native library path for a specific architecture
     */
    fun getRecommendedLibPath(context: Context, preferredAbi: String? = null): String {
        val abi = preferredAbi ?: Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        
        return when (abi) {
            ARCH_ARM64 -> "${context.applicationInfo.nativeLibraryDir}"
            ARCH_ARMV7 -> "${context.applicationInfo.sourceDir}/lib/armeabi-v7a"
            ARCH_X86 -> "${context.applicationInfo.sourceDir}/lib/x86"
            ARCH_X86_64 -> "${context.applicationInfo.sourceDir}/lib/x86_64"
            else -> context.applicationInfo.nativeLibraryDir
        }
    }
    
    /**
     * Get architecture-specific configuration filename
     */
    fun getArchSpecificConfigName(baseName: String, abi: String): String {
        val suffix = when (abi) {
            ARCH_ARM64 -> "_arm64"
            ARCH_ARMV7 -> "_armv7"
            ARCH_X86 -> "_x86"
            ARCH_X86_64 -> "_x86_64"
            else -> ""
        }
        return "${baseName}$suffix.ini"
    }
    
    /**
     * Check if running on emulator
     */
    fun isEmulator(): Boolean {
        return (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic")
                || Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.HARDWARE.contains("goldfish")
                || Build.HARDWARE.contains("ranchu")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || Build.PRODUCT.contains("sdk_google")
                || Build.PRODUCT.contains("google_sdk")
                || Build.PRODUCT.contains("sdk")
                || Build.PRODUCT.contains("sdk_x86")
                || Build.PRODUCT.contains("vbox86p")
                || Build.PRODUCT.contains("emulator")
                || Build.PRODUCT.contains("simulator"))
    }
    
    /**
     * Architecture information data class
     */
    data class ArchitectureInfo(
        val primaryAbi: String,
        val supportedAbis: List<String>,
        val architectureName: String,
        val is64Bit: Boolean,
        val isArm: Boolean,
        val isX86: Boolean,
        val nativeLibDir: String
    ) {
        val isEmulator: Boolean get() = ArchitectureDetector.isEmulator()
        val supportsArm: Boolean get() = supportedAbis.any { it.contains("arm") }
        val supportsX86: Boolean get() = supportedAbis.any { it.contains("x86") }
        
        override fun toString(): String {
            return """
                Architecture: $architectureName
                Primary ABI: $primaryAbi
                64-bit: $is64Bit
                Native Lib Dir: $nativeLibDir
                Emulator: $isEmulator
            """.trimIndent()
        }
    }
}
