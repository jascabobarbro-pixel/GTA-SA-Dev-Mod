package com.gtasa.devmod

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.gtasa.devmod.crash.CrashHandler
import com.gtasa.devmod.databinding.ActivityMainBinding
import com.gtasa.devmod.devtools.DevToolsActivity
import com.gtasa.devmod.modloader.ModLoaderManager
import com.gtasa.devmod.settings.SettingsActivity
import com.gtasa.devmod.storage.StorageManager
import com.gtasa.devmod.utils.ArchitectureDetector
import com.gtasa.devmod.utils.DevModConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Main Activity for GTA SA Dev Mod
 * 
 * Provides the main interface for managing mods, viewing crash logs,
 * and accessing developer tools.
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val PERMISSION_REQUEST_CODE = 1001
    private val ALL_FILES_ACCESS_REQUEST_CODE = 1002
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setSupportActionBar(binding.toolbar)
        
        // Setup UI
        setupUI()
        
        // Check permissions
        checkAndRequestPermissions()
        
        // Load mod information
        loadModInformation()
    }
    
    /**
     * Setup UI components
     */
    private fun setupUI() {
        // Dev Tools button
        binding.btnDevTools.setOnClickListener {
            startActivity(Intent(this, DevToolsActivity::class.java))
        }
        
        // Settings button
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        
        // Scan Mods button
        binding.btnScanMods.setOnClickListener {
            scanForMods()
        }
        
        // View Crash Logs button
        binding.btnViewCrashLogs.setOnClickListener {
            viewCrashLogs()
        }
        
        // Architecture info
        val archInfo = ArchitectureDetector.detectArchitecture(this)
        binding.tvArchitecture.text = getString(
            R.string.architecture_info,
            archInfo.architectureName,
            archInfo.primaryAbi,
            if (archInfo.is64Bit) "64-bit" else "32-bit"
        )
        
        // Storage info
        val storageInfo = StorageManager.getStorageInfo()
        binding.tvStorage.text = getString(
            R.string.storage_info,
            storageInfo.freeSpaceMB,
            storageInfo.totalSpaceMB
        )
    }
    
    /**
     * Check and request necessary permissions
     */
    private fun checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ requires MANAGE_EXTERNAL_STORAGE
            if (!Environment.isExternalStorageManager()) {
                showAllFilesAccessDialog()
            }
        } else {
            // Android 10 and below
            val permissions = mutableListOf<String>()
            
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
            
            if (permissions.isNotEmpty()) {
                ActivityCompat.requestPermissions(
                    this,
                    permissions.toTypedArray(),
                    PERMISSION_REQUEST_CODE
                )
            }
        }
    }
    
    /**
     * Show dialog explaining all files access
     */
    private fun showAllFilesAccessDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.all_files_access_title)
            .setMessage(R.string.all_files_access_message)
            .setPositiveButton(R.string.grant) { _, _ ->
                StorageManager.requestAllFilesAccess(this, ALL_FILES_ACCESS_REQUEST_CODE)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
    
    /**
     * Load mod information
     */
    private fun loadModInformation() {
        CoroutineScope(Dispatchers.IO).launch {
            val result = ModLoaderManager.scanForMods()
            val stats = ModLoaderManager.getModStats()
            
            withContext(Dispatchers.Main) {
                binding.tvModStats.text = getString(
                    R.string.mod_stats,
                    stats.textureCount,
                    stats.modelCount,
                    stats.scriptCount,
                    String.format("%.1f", stats.totalSizeMB)
                )
            }
        }
    }
    
    /**
     * Scan for mods
     */
    private fun scanForMods() {
        binding.btnScanMods.isEnabled = false
        binding.btnScanMods.text = getString(R.string.scanning)
        
        CoroutineScope(Dispatchers.IO).launch {
            val result = ModLoaderManager.scanForMods()
            val stats = ModLoaderManager.getModStats()
            
            withContext(Dispatchers.Main) {
                binding.btnScanMods.isEnabled = true
                binding.btnScanMods.text = getString(R.string.scan_mods)
                
                binding.tvModStats.text = getString(
                    R.string.mod_stats,
                    stats.textureCount,
                    stats.modelCount,
                    stats.scriptCount,
                    String.format("%.1f", stats.totalSizeMB)
                )
                
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.scan_complete, result.textures.size, result.models.size, result.scripts.size),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
    
    /**
     * View crash logs
     */
    private fun viewCrashLogs() {
        val crashLogs = CrashHandler.getCrashLogs()
        
        if (crashLogs.isEmpty()) {
            Toast.makeText(this, R.string.no_crash_logs, Toast.LENGTH_SHORT).show()
            return
        }
        
        val logNames = crashLogs.map { it.name }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle(R.string.crash_logs_title)
            .setItems(logNames) { _, which ->
                // Open crash log details
                val logFile = crashLogs[which]
                showCrashLogDetails(logFile.absolutePath)
            }
            .setPositiveButton(R.string.clear_logs) { _, _ ->
                clearCrashLogs()
            }
            .show()
    }
    
    /**
     * Show crash log details
     */
    private fun showCrashLogDetails(logPath: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.crash_log_details)
            .setMessage("Path: $logPath\n\nTap 'Share' to export this log.")
            .setPositiveButton(R.string.share) { _, _ ->
                shareCrashLog(logPath)
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }
    
    /**
     * Share crash log
     */
    private fun shareCrashLog(logPath: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Crash log location: $logPath")
        }
        startActivity(Intent.createChooser(shareIntent, getString(R.string.share_crash_log)))
    }
    
    /**
     * Clear all crash logs
     */
    private fun clearCrashLogs() {
        CrashHandler.getCrashLogs().forEach { it.delete() }
        Toast.makeText(this, R.string.logs_cleared, Toast.LENGTH_SHORT).show()
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_dev_tools -> {
                startActivity(Intent(this, DevToolsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, R.string.permissions_granted, Toast.LENGTH_SHORT).show()
                StorageManager.initialize(this)
            } else {
                Toast.makeText(this, R.string.permissions_denied, Toast.LENGTH_LONG).show()
            }
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ALL_FILES_ACCESS_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
                Toast.makeText(this, R.string.all_files_access_granted, Toast.LENGTH_SHORT).show()
                StorageManager.initialize(this)
            }
        }
    }
}
