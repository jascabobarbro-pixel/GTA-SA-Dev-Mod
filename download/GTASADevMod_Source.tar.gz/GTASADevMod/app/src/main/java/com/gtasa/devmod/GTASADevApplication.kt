package com.gtasa.devmod

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.gtasa.devmod.crash.CrashHandler
import com.gtasa.devmod.modloader.ModLoaderManager
import com.gtasa.devmod.storage.StorageManager
import com.gtasa.devmod.utils.ArchitectureDetector
import com.gtasa.devmod.utils.DevModConfig

/**
 * GTA SA Dev Mod Application
 * Ultimate Edition with Android 15 Support
 * 
 * This application provides a comprehensive modding environment for GTA San Andreas Android.
 * Features include:
 * - Advanced crash reporting with timestamped logs
 * - Android 15+ scoped storage compliance
 * - Automatic architecture detection and native library selection
 * - CLEO script execution support
 * - TXD/IMG auto-detection and loading
 */
class GTASADevApplication : Application() {

    companion object {
        const val NOTIFICATION_CHANNEL_MODS = "mod_operations"
        const val NOTIFICATION_CHANNEL_CRASH = "crash_reports"
        
        @Volatile
        private var instance: GTASADevApplication? = null
        
        fun getInstance(): GTASADevApplication {
            return instance ?: throw IllegalStateException("Application not initialized")
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        
        // Initialize configuration
        DevModConfig.initialize(this)
        
        // Setup crash handler first
        CrashHandler.initialize(this)
        
        // Create notification channels
        createNotificationChannels()
        
        // Detect CPU architecture
        val archInfo = ArchitectureDetector.detectArchitecture(this)
        DevModConfig.setDetectedArchitecture(archInfo)
        
        // Initialize storage manager
        StorageManager.initialize(this)
        
        // Initialize mod loader
        ModLoaderManager.initialize(this)
        
        // Load native library
        loadNativeLibrary(archInfo)
    }
    
    /**
     * Load the appropriate native library based on detected architecture.
     * Supports ARM64, ARMv7, x86, and x86_64.
     */
    private fun loadNativeLibrary(archInfo: ArchitectureDetector.ArchitectureInfo) {
        try {
            // The native library is named the same but we load from the correct
            // lib directory based on ABI filtering in build.gradle
            System.loadLibrary("gtasadevmod")
            
            // Initialize native side
            nativeInitialize(
                archInfo.primaryAbi,
                archInfo.is64Bit,
                StorageManager.getWorkingDirectory(),
                StorageManager.getLogDirectory()
            )
        } catch (e: UnsatisfiedLinkError) {
            CrashHandler.logNativeError("Failed to load native library: ${e.message}")
        }
    }
    
    /**
     * Create notification channels for Android O+
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)
            
            // Mod operations channel
            val modChannel = NotificationChannel(
                NOTIFICATION_CHANNEL_MODS,
                getString(R.string.notification_channel_mods),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_mods_desc)
            }
            notificationManager.createNotificationChannel(modChannel)
            
            // Crash reports channel
            val crashChannel = NotificationChannel(
                NOTIFICATION_CHANNEL_CRASH,
                getString(R.string.notification_channel_crash),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notification_channel_crash_desc)
            }
            notificationManager.createNotificationChannel(crashChannel)
        }
    }
    
    // Native methods
    private external fun nativeInitialize(
        abi: String,
        is64Bit: Boolean,
        workingDir: String,
        logDir: String
    )
}
