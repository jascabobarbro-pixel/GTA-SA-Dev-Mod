package com.gtasa.devmod.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import androidx.preference.SeekBarPreference
import com.gtasa.devmod.R
import com.gtasa.devmod.utils.DevModConfig

/**
 * Settings Activity
 * 
 * Provides configuration options for the GTA SA Dev Mod.
 */
class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
    
    /**
     * Settings Fragment using AndroidX Preference library
     */
    class SettingsFragment : PreferenceFragmentCompat() {
        
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            
            // Setup preferences
            setupPerformancePreferences()
            setupModdingPreferences()
            setupDebugPreferences()
        }
        
        private fun setupPerformancePreferences() {
            findPreference<SwitchPreferenceCompat>("high_mem_mode")?.apply {
                isChecked = DevModConfig.isHighMemoryModeEnabled()
                setOnPreferenceChangeListener { _, newValue ->
                    DevModConfig.setBoolean(DevModConfig.KEY_HIGH_MEM_MODE, newValue as Boolean)
                    true
                }
            }
            
            findPreference<SeekBarPreference>("max_heap_size")?.apply {
                value = DevModConfig.getMaxHeapSizeMB()
                setOnPreferenceChangeListener { _, newValue ->
                    DevModConfig.setInt(DevModConfig.KEY_MAX_HEAP_SIZE_MB, (newValue as Int))
                    true
                }
            }
        }
        
        private fun setupModdingPreferences() {
            findPreference<SwitchPreferenceCompat>("auto_load_textures")?.apply {
                isChecked = DevModConfig.getBoolean(DevModConfig.KEY_AUTO_LOAD_TXD)
                setOnPreferenceChangeListener { _, newValue ->
                    DevModConfig.setBoolean(DevModConfig.KEY_AUTO_LOAD_TXD, newValue as Boolean)
                    true
                }
            }
            
            findPreference<SwitchPreferenceCompat>("auto_load_img")?.apply {
                isChecked = DevModConfig.getBoolean(DevModConfig.KEY_AUTO_LOAD_IMG)
                setOnPreferenceChangeListener { _, newValue ->
                    DevModConfig.setBoolean(DevModConfig.KEY_AUTO_LOAD_IMG, newValue as Boolean)
                    true
                }
            }
            
            findPreference<SwitchPreferenceCompat>("cleo_enabled")?.apply {
                isChecked = DevModConfig.getBoolean(DevModConfig.KEY_CLEO_ENABLED)
                setOnPreferenceChangeListener { _, newValue ->
                    DevModConfig.setBoolean(DevModConfig.KEY_CLEO_ENABLED, newValue as Boolean)
                    true
                }
            }
        }
        
        private fun setupDebugPreferences() {
            findPreference<SwitchPreferenceCompat>("debug_mode")?.apply {
                isChecked = DevModConfig.getBoolean(DevModConfig.KEY_DEBUG_MODE)
                setOnPreferenceChangeListener { _, newValue ->
                    DevModConfig.setBoolean(DevModConfig.KEY_DEBUG_MODE, newValue as Boolean)
                    true
                }
            }
        }
    }
}
