package com.gtasa.devmod.devtools

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.gtasa.devmod.R
import com.gtasa.devmod.databinding.ActivityDevToolsBinding
import com.gtasa.devmod.modloader.ModLoaderManager
import com.gtasa.devmod.storage.StorageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Dev Tools Activity
 * 
 * Provides developer tools for:
 * - Script editing
 * - CLEO script execution
 * - Texture viewing
 * - Log viewing
 */
class DevToolsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDevToolsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDevToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        setupButtons()
    }
    
    private fun setupButtons() {
        // Script Runner
        binding.btnScriptRunner.setOnClickListener {
            showScriptRunner()
        }
        
        // Texture Viewer
        binding.btnTextureViewer.setOnClickListener {
            showTextureViewer()
        }
        
        // Log Viewer
        binding.btnLogViewer.setOnClickListener {
            showLogViewer()
        }
        
        // Generate Report
        binding.btnGenerateReport.setOnClickListener {
            generateSystemReport()
        }
    }
    
    /**
     * Show script runner dialog
     */
    private fun showScriptRunner() {
        val scripts = ModLoaderManager.getLoadedScripts().values.toList()
        
        if (scripts.isEmpty()) {
            Toast.makeText(this, "No scripts found. Add .cs or .scm files to /sdcard/GTA_SA_Dev/cleo/", Toast.LENGTH_LONG).show()
            return
        }
        
        val scriptNames = scripts.map { it.name }.toTypedArray()
        val scriptPaths = scripts.map { it.path }.toTypedArray()
        val enabledStates = scripts.map { it.enabled }.toBooleanArray()
        
        AlertDialog.Builder(this)
            .setTitle(R.string.cleo_runner)
            .setMultiChoiceItems(scriptNames, enabledStates) { _, which, isChecked ->
                ModLoaderManager.setScriptEnabled(scriptPaths[which], isChecked)
            }
            .setPositiveButton("Run Selected") { _, _ ->
                runSelectedScripts(scripts)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
    
    /**
     * Run selected scripts
     */
    private fun runSelectedScripts(scripts: List<ModLoaderManager.ScriptInfo>) {
        CoroutineScope(Dispatchers.IO).launch {
            var executed = 0
            scripts.filter { it.enabled }.forEach { script ->
                // Script execution would happen here
                executed++
            }
            
            withContext(Dispatchers.Main) {
                Toast.makeText(this@DevToolsActivity, "Executed $executed scripts", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    /**
     * Show texture viewer
     */
    private fun showTextureViewer() {
        val textures = ModLoaderManager.getLoadedTextures().values.toList()
        
        if (textures.isEmpty()) {
            Toast.makeText(this, "No textures found. Add .txd or .img files to /sdcard/GTA_SA_Dev/textures/", Toast.LENGTH_LONG).show()
            return
        }
        
        val textureNames = textures.take(20).map { 
            "${it.name}.${it.extension} (${formatSize(it.size)})"
        }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle(R.string.texture_viewer)
            .setItems(textureNames, null)
            .setPositiveButton("View All (${textures.size})", null)
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
    
    /**
     * Show log viewer
     */
    private fun showLogViewer() {
        val logDir = File(StorageManager.getLogDirectory())
        val logFiles = logDir.listFiles { file ->
            file.name.endsWith(".log") || file.name.startsWith("crash_log_")
        }?.sortedByDescending { it.lastModified() } ?: emptyList()
        
        if (logFiles.isEmpty()) {
            Toast.makeText(this, "No log files found", Toast.LENGTH_SHORT).show()
            return
        }
        
        val logNames = logFiles.take(10).map { it.name }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle(R.string.log_viewer)
            .setItems(logNames) { _, which ->
                showLogFileContent(logFiles[which])
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
    
    /**
     * Show log file content
     */
    private fun showLogFileContent(logFile: File) {
        try {
            val content = logFile.readText().take(5000)
            
            AlertDialog.Builder(this)
                .setTitle(logFile.name)
                .setMessage(content + if (logFile.length() > 5000) "\n\n... (truncated)" else "")
                .setPositiveButton(android.R.string.ok, null)
                .show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to read log: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    /**
     * Generate system report
     */
    private fun generateSystemReport() {
        CoroutineScope(Dispatchers.IO).launch {
            val report = buildString {
                appendLine("GTA SA Dev Mod - System Report")
                appendLine("=" .repeat(40))
                appendLine()
                appendLine("Device Information:")
                appendLine("- Manufacturer: ${android.os.Build.MANUFACTURER}")
                appendLine("- Model: ${android.os.Build.MODEL}")
                appendLine("- Android: ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})")
                appendLine("- ABIs: ${android.os.Build.SUPPORTED_ABIS.joinToString(", ")}")
                appendLine()
                appendLine("Storage:")
                val storageInfo = StorageManager.getStorageInfo()
                appendLine("- Total: ${storageInfo.totalSpaceMB} MB")
                appendLine("- Free: ${storageInfo.freeSpaceMB} MB")
                appendLine("- All Files Access: ${storageInfo.hasAllFilesAccess}")
                appendLine()
                appendLine("Mods:")
                val modStats = ModLoaderManager.getModStats()
                appendLine("- Textures: ${modStats.textureCount}")
                appendLine("- Models: ${modStats.modelCount}")
                appendLine("- Scripts: ${modStats.scriptCount}")
                appendLine("- Total Size: ${String.format("%.1f", modStats.totalSizeMB)} MB")
            }
            
            // Save report
            val reportFile = File(StorageManager.getLogDirectory(), "system_report_${System.currentTimeMillis()}.txt")
            reportFile.writeText(report)
            
            withContext(Dispatchers.Main) {
                AlertDialog.Builder(this@DevToolsActivity)
                    .setTitle("System Report Generated")
                    .setMessage(report)
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
            }
        }
    }
    
    private fun formatSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> String.format("%.1f KB", bytes / 1024.0)
            else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
