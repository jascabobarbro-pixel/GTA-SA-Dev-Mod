package com.gtasa.devmod.utils

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.gtasa.devmod.storage.StorageManager
import org.json.JSONObject
import java.io.File

/**
 * DevMod Configuration Manager
 * 
 * Manages application settings and configuration files for the GTA SA Dev Mod.
 * Supports both SharedPreferences and INI-style configuration files.
 */
object DevModConfig {
    
    private const val TAG = "DevModConfig"
    private const val PREFS_NAME = "gtasa_devmod_prefs"
    
    // Configuration keys
    const val KEY_HIGH_MEM_MODE = "EnableHighMemMode"
    const val KEY_AUTO_LOAD_TXD = "AutoLoadTXD"
    const val KEY_AUTO_LOAD_IMG = "AutoLoadIMG"
    const val KEY_CLEO_ENABLED = "CLEOEnabled"
    const val KEY_DEBUG_MODE = "DebugMode"
    const val KEY_LOG_LEVEL = "LogLevel"
    const val KEY_MAX_HEAP_SIZE_MB = "MaxHeapSizeMB"
    const val KEY_ENABLE_VSYNC = "EnableVSync"
    const val KEY_TEXTURE_QUALITY = "TextureQuality"
    const val KEY_DRAW_DISTANCE = "DrawDistance"
    
    private lateinit var appContext: Context
    private lateinit var prefs: SharedPreferences
    private var configDir: File? = null
    private var detectedArch: ArchitectureDetector.ArchitectureInfo? = null
    private var archInfo: ArchitectureDetector.ArchitectureInfo? = null
    
    // Default values
    private val defaults = mapOf(
        KEY_HIGH_MEM_MODE to true,
        KEY_AUTO_LOAD_TXD to true,
        KEY_AUTO_LOAD_IMG to true,
        KEY_CLEO_ENABLED to true,
        KEY_DEBUG_MODE to false,
        KEY_LOG_LEVEL to 2, // INFO level
        KEY_MAX_HEAP_SIZE_MB to 512,
        KEY_ENABLE_VSYNC to true,
        KEY_TEXTURE_QUALITY to 2, // High
        KEY_DRAW_DISTANCE to 1.0f
    )
    
    /**
     * Initialize the configuration manager
     */
    fun initialize(context: Context) {
        appContext = context.applicationContext
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        
        // Setup config directory
        configDir = StorageManager.getConfigDirectory()
        
        // Load settings.ini if exists
        loadSettingsFile()
        
        Log.i(TAG, "Configuration initialized")
    }
    
    /**
     * Set the detected architecture info
     */
    fun setDetectedArchitecture(arch: ArchitectureDetector.ArchitectureInfo) {
        archInfo = arch
    }
    
    /**
     * Get the detected architecture info
     */
    fun getDetectedArchitecture(): ArchitectureDetector.ArchitectureInfo? = archInfo
    
    /**
     * Load settings from settings.ini file
     */
    private fun loadSettingsFile() {
        val settingsFile = File(configDir, "settings.ini")
        if (settingsFile.exists()) {
            try {
                settingsFile.readLines().forEach { line ->
                    val trimmed = line.trim()
                    if (trimmed.isNotEmpty() && !trimmed.startsWith(";") && !trimmed.startsWith("#")) {
                        val parts = trimmed.split("=", limit = 2)
                        if (parts.size == 2) {
                            val key = parts[0].trim()
                            val value = parts[1].trim()
                            parseAndSetValue(key, value)
                        }
                    }
                }
                Log.i(TAG, "Loaded settings from settings.ini")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load settings.ini: ${e.message}")
            }
        } else {
            // Create default settings.ini
            createDefaultSettingsFile()
        }
    }
    
    /**
     * Parse a value string and set it in preferences
     */
    private fun parseAndSetValue(key: String, value: String) {
        when {
            value.equals("true", ignoreCase = true) -> prefs.edit().putBoolean(key, true).apply()
            value.equals("false", ignoreCase = true) -> prefs.edit().putBoolean(key, false).apply()
            value.contains(".") -> prefs.edit().putFloat(key, value.toFloat()).apply()
            else -> {
                val longValue = value.toLongOrNull()
                if (longValue != null) {
                    prefs.edit().putLong(key, longValue).apply()
                } else {
                    prefs.edit().putString(key, value).apply()
                }
            }
        }
    }
    
    /**
     * Create a default settings.ini file
     */
    private fun createDefaultSettingsFile() {
        val settingsFile = File(configDir, "settings.ini")
        try {
            settingsFile.writeText("""
                ; GTA SA Dev Mod - Settings Configuration
                ; Generated automatically - You can modify these values
                
                [Performance]
                EnableHighMemMode = true
                MaxHeapSizeMB = 512
                
                [Modding]
                AutoLoadTXD = true
                AutoLoadIMG = true
                CLEOEnabled = true
                
                [Graphics]
                EnableVSync = true
                TextureQuality = 2
                DrawDistance = 1.0
                
                [Debug]
                DebugMode = false
                LogLevel = 2
            """.trimIndent())
            Log.i(TAG, "Created default settings.ini")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create settings.ini: ${e.message}")
        }
    }
    
    /**
     * Get a boolean value
     */
    fun getBoolean(key: String, default: Boolean = defaults[key] as? Boolean ?: false): Boolean {
        return prefs.getBoolean(key, default)
    }
    
    /**
     * Get an integer value
     */
    fun getInt(key: String, default: Int = defaults[key] as? Int ?: 0): Int {
        return prefs.getInt(key, default)
    }
    
    /**
     * Get a float value
     */
    fun getFloat(key: String, default: Float = defaults[key] as? Float ?: 0f): Float {
        return prefs.getFloat(key, default)
    }
    
    /**
     * Get a string value
     */
    fun getString(key: String, default: String = ""): String {
        return prefs.getString(key, default) ?: default
    }
    
    /**
     * Get a long value
     */
    fun getLong(key: String, default: Long = defaults[key] as? Long ?: 0L): Long {
        return prefs.getLong(key, default)
    }
    
    /**
     * Set a boolean value
     */
    fun setBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }
    
    /**
     * Set an integer value
     */
    fun setInt(key: String, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }
    
    /**
     * Set a float value
     */
    fun setFloat(key: String, value: Float) {
        prefs.edit().putFloat(key, value).apply()
    }
    
    /**
     * Set a string value
     */
    fun setString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }
    
    /**
     * Check if high memory mode is enabled
     */
    fun isHighMemoryModeEnabled(): Boolean = getBoolean(KEY_HIGH_MEM_MODE, true)
    
    /**
     * Get max heap size for heavy mods
     */
    fun getMaxHeapSizeMB(): Int = getInt(KEY_MAX_HEAP_SIZE_MB, 512)
    
    /**
     * Export configuration to JSON
     */
    fun exportToJson(): String {
        val json = JSONObject()
        defaults.keys.forEach { key ->
            val value = prefs.all[key] ?: defaults[key]!!
            json.put(key, value)
        }
        return json.toString(2)
    }
    
    /**
     * Import configuration from JSON
     */
    fun importFromJson(jsonString: String) {
        try {
            val json = JSONObject(jsonString)
            val editor = prefs.edit()
            json.keys().forEach { key ->
                when (val value = json.get(key)) {
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                    is String -> editor.putString(key, value)
                }
            }
            editor.apply()
            Log.i(TAG, "Imported configuration from JSON")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to import configuration: ${e.message}")
        }
    }
}
