package com.gtasa.devmod.modloader

import android.content.Context
import android.util.Log
import com.gtasa.devmod.storage.StorageManager
import com.gtasa.devmod.utils.DevModConfig
import java.io.File

/**
 * Mod Loader Manager
 * 
 * Comprehensive mod loading system for GTA SA Android.
 * Features:
 * - Auto-detection for TXD/Database files
 * - Recursive scanning of texture directories
 * - Heavy mod support framework
 * - CLEO script execution support
 * - Memory optimization for large mods
 */
object ModLoaderManager {
    
    private const val TAG = "ModLoaderManager"
    
    // Supported file extensions
    private val TEXTURE_EXTENSIONS = setOf(".txd", ".img")
    private val MODEL_EXTENSIONS = setOf(".dff", ".col")
    private val SCRIPT_EXTENSIONS = setOf(".cs", ".scm", ".cleo")
    
    private lateinit var appContext: Context
    private var loadedTextures = mutableMapOf<String, TextureInfo>()
    private var loadedModels = mutableMapOf<String, ModelInfo>()
    private var loadedScripts = mutableMapOf<String, ScriptInfo>()
    private var isInitialized = false
    
    /**
     * Initialize the mod loader
     */
    fun initialize(context: Context) {
        if (isInitialized) return
        
        appContext = context.applicationContext
        
        // Setup memory for heavy mods
        setupMemoryConfiguration()
        
        isInitialized = true
        Log.i(TAG, "Mod loader initialized")
    }
    
    /**
     * Setup memory configuration for heavy mods
     */
    private fun setupMemoryConfiguration() {
        val highMemMode = DevModConfig.isHighMemoryModeEnabled()
        val maxHeapMB = DevModConfig.getMaxHeapSizeMB()
        
        Log.i(TAG, "Memory config - HighMemMode: $highMemMode, MaxHeap: ${maxHeapMB}MB")
        
        // Notify native side about memory configuration
        try {
            setMemoryConfig(highMemMode, maxHeapMB)
        } catch (e: UnsatisfiedLinkError) {
            Log.w(TAG, "Native memory config not available")
        }
    }
    
    /**
     * Scan for all mods in the working directory
     */
    fun scanForMods(): ScanResult {
        Log.i(TAG, "Scanning for mods...")
        
        val result = ScanResult()
        
        // Scan textures
        if (DevModConfig.getBoolean(DevModConfig.KEY_AUTO_LOAD_TXD)) {
            result.textures = scanTexturesDirectory()
        }
        
        // Scan models
        result.models = scanModelsDirectory()
        
        // Scan CLEO scripts
        if (DevModConfig.getBoolean(DevModConfig.KEY_CLEO_ENABLED)) {
            result.scripts = scanCleoDirectory()
        }
        
        Log.i(TAG, "Scan complete: ${result.textures.size} textures, ${result.models.size} models, ${result.scripts.size} scripts")
        return result
    }
    
    /**
     * Recursively scan the textures directory for TXD and IMG files
     * Eliminates the need for manual renaming
     */
    fun scanTexturesDirectory(): List<TextureInfo> {
        val texturesDir = StorageManager.getTexturesDirectory()
        val textures = mutableListOf<TextureInfo>()
        
        if (!texturesDir.exists()) {
            Log.w(TAG, "Textures directory does not exist: ${texturesDir.absolutePath}")
            return textures
        }
        
        // Recursive scan
        scanTexturesRecursive(texturesDir, textures)
        
        Log.i(TAG, "Found ${textures.size} texture files")
        return textures
    }
    
    /**
     * Recursive helper for texture scanning
     */
    private fun scanTexturesRecursive(dir: File, textures: MutableList<TextureInfo>) {
        dir.listFiles()?.forEach { file ->
            if (file.isDirectory) {
                // Recurse into subdirectories
                scanTexturesRecursive(file, textures)
            } else {
                val extension = file.extension.lowercase()
                if (extension in TEXTURE_EXTENSIONS || ".$extension" in TEXTURE_EXTENSIONS) {
                    val info = TextureInfo(
                        name = file.nameWithoutExtension,
                        path = file.absolutePath,
                        extension = extension,
                        size = file.length(),
                        lastModified = file.lastModified()
                    )
                    textures.add(info)
                    loadedTextures[file.absolutePath] = info
                }
            }
        }
    }
    
    /**
     * Scan the models directory for DFF and COL files
     */
    fun scanModelsDirectory(): List<ModelInfo> {
        val modelsDir = StorageManager.getModelsDirectory()
        val models = mutableListOf<ModelInfo>()
        
        if (!modelsDir.exists()) {
            return models
        }
        
        modelsDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                val extension = file.extension.lowercase()
                if (extension in MODEL_EXTENSIONS || ".$extension" in MODEL_EXTENSIONS) {
                    val info = ModelInfo(
                        name = file.nameWithoutExtension,
                        path = file.absolutePath,
                        extension = extension,
                        size = file.length()
                    )
                    models.add(info)
                    loadedModels[file.absolutePath] = info
                }
            }
        }
        
        return models
    }
    
    /**
     * Scan the CLEO directory for scripts
     */
    fun scanCleoDirectory(): List<ScriptInfo> {
        val cleoDir = StorageManager.getCleoDirectory()
        val scripts = mutableListOf<ScriptInfo>()
        
        if (!cleoDir.exists()) {
            return scripts
        }
        
        cleoDir.listFiles()?.forEach { file ->
            if (file.isFile) {
                val extension = file.extension.lowercase()
                if (extension in SCRIPT_EXTENSIONS || ".$extension" in SCRIPT_EXTENSIONS) {
                    val info = ScriptInfo(
                        name = file.nameWithoutExtension,
                        path = file.absolutePath,
                        extension = extension,
                        size = file.length(),
                        enabled = true // Default to enabled
                    )
                    scripts.add(info)
                    loadedScripts[file.absolutePath] = info
                }
            }
        }
        
        return scripts
    }
    
    /**
     * Auto-load all discovered texture files
     */
    fun autoLoadTextures(): Int {
        var loaded = 0
        loadedTextures.values.forEach { texture ->
            try {
                if (loadTextureFile(texture.path)) {
                    loaded++
                    Log.d(TAG, "Loaded texture: ${texture.name}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load texture ${texture.name}: ${e.message}")
            }
        }
        return loaded
    }
    
    /**
     * Execute all CLEO scripts
     */
    fun executeScripts(): Int {
        var executed = 0
        loadedScripts.values.filter { it.enabled }.forEach { script ->
            try {
                if (executeScriptFile(script.path)) {
                    executed++
                    Log.d(TAG, "Executed script: ${script.name}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to execute script ${script.name}: ${e.message}")
            }
        }
        return executed
    }
    
    /**
     * Get all loaded texture info
     */
    fun getLoadedTextures(): Map<String, TextureInfo> = loadedTextures.toMap()
    
    /**
     * Get all loaded model info
     */
    fun getLoadedModels(): Map<String, ModelInfo> = loadedModels.toMap()
    
    /**
     * Get all loaded script info
     */
    fun getLoadedScripts(): Map<String, ScriptInfo> = loadedScripts.toMap()
    
    /**
     * Enable or disable a script
     */
    fun setScriptEnabled(scriptPath: String, enabled: Boolean) {
        loadedScripts[scriptPath]?.enabled = enabled
    }
    
    /**
     * Get mod statistics
     */
    fun getModStats(): ModStats {
        return ModStats(
            textureCount = loadedTextures.size,
            modelCount = loadedModels.size,
            scriptCount = loadedScripts.size,
            totalSize = loadedTextures.values.sumOf { it.size } +
                        loadedModels.values.sumOf { it.size } +
                        loadedScripts.values.sumOf { it.size }
        )
    }
    
    // Native methods
    private external fun setMemoryConfig(highMemMode: Boolean, maxHeapMB: Int)
    private external fun loadTextureFile(path: String): Boolean
    private external fun executeScriptFile(path: String): Boolean
    
    // Data classes
    data class TextureInfo(
        val name: String,
        val path: String,
        val extension: String,
        val size: Long,
        val lastModified: Long
    )
    
    data class ModelInfo(
        val name: String,
        val path: String,
        val extension: String,
        val size: Long
    )
    
    data class ScriptInfo(
        val name: String,
        val path: String,
        val extension: String,
        val size: Long,
        var enabled: Boolean
    )
    
    data class ScanResult(
        var textures: List<TextureInfo> = emptyList(),
        var models: List<ModelInfo> = emptyList(),
        var scripts: List<ScriptInfo> = emptyList()
    )
    
    data class ModStats(
        val textureCount: Int,
        val modelCount: Int,
        val scriptCount: Int,
        val totalSize: Long
    ) {
        val totalSizeMB: Double get() = totalSize / (1024.0 * 1024.0)
    }
}
