package com.gtasa.devmod.crash

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.Process
import android.util.Log
import android.widget.Toast
import com.gtasa.devmod.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Advanced Crash Handler with timestamped log files and Toast notifications.
 * 
 * This class implements both Java-side and interfaces with Native C++ crash handlers
 * to provide comprehensive crash reporting for the GTA SA Dev Mod environment.
 * 
 * Features:
 * - Thread.UncaughtExceptionHandler for Java crashes
 * - Signal handlers integration for Native C++ crashes
 * - Timestamped crash log files: crash_log_[timestamp].txt
 * - Toast/Dialog notification before app termination
 * - Automatic log directory creation in Documents/GTA_SA_Dev/Logs
 */
object CrashHandler {
    
    private const val TAG = "CrashHandler"
    private const val CRASH_LOG_PREFIX = "crash_log_"
    private const val CRASH_LOG_EXTENSION = ".txt"
    
    private lateinit var appContext: Context
    private var logDirectory: File? = null
    private var isInitialized = false
    
    // Date format for timestamped crash logs
    private val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    
    /**
     * Initialize the crash handler. Must be called in Application.onCreate()
     */
    fun initialize(context: Context) {
        if (isInitialized) return
        
        appContext = context.applicationContext
        
        // Create log directory
        setupLogDirectory()
        
        // Set up Java crash handler
        Thread.setDefaultUncaughtExceptionHandler(CrashUncaughtExceptionHandler())
        
        // Initialize native crash handler
        try {
            initNativeCrashHandler(logDirectory?.absolutePath)
        } catch (e: UnsatisfiedLinkError) {
            Log.w(TAG, "Native crash handler not available: ${e.message}")
        }
        
        isInitialized = true
        Log.i(TAG, "Crash handler initialized successfully")
    }
    
    /**
     * Setup the log directory at Documents/GTA_SA_Dev/Logs
     * This is accessible without scoped storage permissions on all Android versions.
     */
    private fun setupLogDirectory() {
        try {
            // Primary location: Documents/GTA_SA_Dev/Logs
            val documentsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            logDirectory = File(documentsDir, "GTA_SA_Dev/Logs").apply {
                if (!exists()) {
                    val created = mkdirs()
                    Log.i(TAG, "Log directory created: $absolutePath ($created)")
                }
            }
            
            // Create .nomedia to prevent media scanning
            File(logDirectory, ".nomedia").createNewFile()
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create log directory: ${e.message}")
            // Fallback to app-specific directory
            logDirectory = File(appContext.filesDir, "crash_logs").apply {
                mkdirs()
            }
        }
    }
    
    /**
     * Generate a timestamped crash log filename
     */
    private fun generateCrashLogFilename(): String {
        val timestamp = dateFormat.format(Date())
        return "$CRASH_LOG_PREFIX$timestamp$CRASH_LOG_EXTENSION"
    }
    
    /**
     * Write crash information to a timestamped log file
     */
    fun writeCrashLog(thread: Thread?, throwable: Throwable?, extraInfo: String? = null): File? {
        val logFile = File(logDirectory, generateCrashLogFilename())
        
        try {
            FileWriter(logFile, true).use { writer ->
                // Header
                writer.write("=".repeat(60) + "\n")
                writer.write("GTA SA DEV MOD - CRASH LOG\n")
                writer.write("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())}\n")
                writer.write("=".repeat(60) + "\n\n")
                
                // Device Info
                writer.write("--- Device Information ---\n")
                writer.write("Device: ${Build.DEVICE}\n")
                writer.write("Model: ${Build.MODEL}\n")
                writer.write("Manufacturer: ${Build.MANUFACTURER}\n")
                writer.write("Brand: ${Build.BRAND}\n")
                writer.write("Android Version: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
                writer.write("Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString(", ")}\n")
                writer.write("\n")
                
                // App Info
                writer.write("--- Application Information ---\n")
                try {
                    val packageInfo = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
                    writer.write("Version: ${packageInfo.versionName} (${packageInfo.longVersionCode})\n")
                } catch (e: Exception) {
                    writer.write("Version: Unknown\n")
                }
                writer.write("Package: ${appContext.packageName}\n")
                writer.write("\n")
                
                // Thread Info
                writer.write("--- Thread Information ---\n")
                writer.write("Crashed Thread: ${thread?.name ?: "Unknown"} (ID: ${thread?.id ?: "N/A"})\n")
                writer.write("Thread State: ${thread?.state ?: "Unknown"}\n")
                writer.write("\n")
                
                // Stack Trace
                writer.write("--- Stack Trace ---\n")
                if (throwable != null) {
                    val stringWriter = StringWriter()
                    val printWriter = PrintWriter(stringWriter)
                    throwable.printStackTrace(printWriter)
                    writer.write(stringWriter.toString())
                } else {
                    writer.write("No Java exception available (possibly native crash)\n")
                }
                writer.write("\n")
                
                // Extra Info
                if (!extraInfo.isNullOrBlank()) {
                    writer.write("--- Additional Information ---\n")
                    writer.write(extraInfo)
                    writer.write("\n")
                }
                
                // Memory Info
                writer.write("--- Memory Information ---\n")
                val runtime = Runtime.getRuntime()
                writer.write("Max Memory: ${runtime.maxMemory() / (1024 * 1024)} MB\n")
                writer.write("Total Memory: ${runtime.totalMemory() / (1024 * 1024)} MB\n")
                writer.write("Free Memory: ${runtime.freeMemory() / (1024 * 1024)} MB\n")
                writer.write("\n")
                
                // Footer
                writer.write("=".repeat(60) + "\n")
                writer.write("END OF CRASH LOG\n")
                writer.write("Please report this crash to the developers\n")
                writer.write("GitHub: https://github.com/GTASA-DevMod/GTA-SA-Dev-Mod\n")
                writer.write("=".repeat(60) + "\n")
            }
            
            Log.i(TAG, "Crash log written to: ${logFile.absolutePath}")
            return logFile
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write crash log: ${e.message}")
            return null
        }
    }
    
    /**
     * Write a native crash log from C++ side
     */
    fun writeNativeCrashLog(crashInfo: String): File? {
        return writeCrashLog(null, null, crashInfo)
    }
    
    /**
     * Log a native error (for UnsatisfiedLinkError etc.)
     */
    fun logNativeError(message: String) {
        Log.e(TAG, "Native Error: $message")
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val logFile = File(logDirectory, "native_errors.log")
                FileWriter(logFile, true).use { writer ->
                    writer.write("[${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}] $message\n")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to write native error log: ${e.message}")
            }
        }
    }
    
    /**
     * Show crash notification to user
     */
    fun showCrashNotification(logFile: File?) {
        val message = if (logFile != null) {
            appContext.getString(R.string.crash_detected_log_saved, logFile.absolutePath)
        } else {
            appContext.getString(R.string.crash_detected)
        }
        
        // Show toast (works even if app is crashing)
        Toast.makeText(appContext, message, Toast.LENGTH_LONG).show()
    }
    
    /**
     * Get the log directory path
     */
    fun getLogDirectory(): String? = logDirectory?.absolutePath
    
    /**
     * Get all crash logs
     */
    fun getCrashLogs(): List<File> {
        return logDirectory?.listFiles { file ->
            file.name.startsWith(CRASH_LOG_PREFIX) && file.name.endsWith(CRASH_LOG_EXTENSION)
        }?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
    
    /**
     * Clean up old crash logs (keep last 20)
     */
    fun cleanupOldLogs() {
        val logs = getCrashLogs()
        if (logs.size > 20) {
            logs.drop(20).forEach { it.delete() }
        }
    }
    
    // Native method to initialize native crash handler
    private external fun initNativeCrashHandler(logDir: String?)
    
    /**
     * Custom UncaughtExceptionHandler for catching Java crashes
     */
    private inner class CrashUncaughtExceptionHandler : Thread.UncaughtExceptionHandler {
        
        private val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        
        override fun uncaughtException(thread: Thread, throwable: Throwable) {
            Log.e(TAG, "Uncaught exception in thread: ${thread.name}", throwable)
            
            // Write crash log
            val logFile = writeCrashLog(thread, throwable)
            
            // Show notification
            showCrashNotification(logFile)
            
            // Give some time for the toast to show
            try {
                Thread.sleep(500)
            } catch (e: InterruptedException) {
                // Ignore
            }
            
            // Notify native side about crash
            try {
                onJavaCrash(throwable.javaClass.name, throwable.message ?: "No message")
            } catch (e: Exception) {
                // Ignore if native method fails
            }
            
            // Call default handler (usually kills the process)
            defaultHandler?.uncaughtException(thread, throwable) ?: run {
                Process.killProcess(Process.myPid())
                System.exit(1)
            }
        }
    }
    
    // Native callback for Java crash notification
    private external fun onJavaCrash(exceptionClass: String, message: String)
}
