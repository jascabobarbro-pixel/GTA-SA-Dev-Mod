/**
 * GTA SA Dev Mod - Mod Loader
 * 
 * Native mod loading infrastructure with:
 * - Memory configuration for heavy mods
 * - Map boundary extension support
 * - Heap size management
 */

#include <string>
#include <android/log.h>

#include "mod_loader.h"

#define LOG_TAG "ModLoader-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Global state
bool g_highMemoryMode = false;
int g_maxHeapSizeMB = 512;
static size_t g_extendedHeapSize = 0;

/**
 * Configure memory for heavy mods
 */
static void configureMemory(bool highMemMode, int maxHeapMB) {
    g_highMemoryMode = highMemMode;
    g_maxHeapSizeMB = maxHeapMB;
    
    if (highMemMode) {
        // Calculate extended heap size
        g_extendedHeapSize = (size_t)maxHeapMB * 1024 * 1024;
        
        LOGI("High Memory Mode enabled");
        LOGI("Max heap size: %d MB (%zu bytes)", maxHeapMB, g_extendedHeapSize);
        
        // Additional memory configuration for heavy mods
        // This allows loading larger map boundaries and graphics mods
    } else {
        LOGI("Standard memory mode");
    }
}

/**
 * Initialize the mod loader
 */
void InitModLoader(bool highMemMode, int maxHeapMB) {
    LOGI("Initializing Mod Loader");
    
    // Configure memory
    configureMemory(highMemMode, maxHeapMB);
    
    // Additional initialization for mod loading infrastructure
    LOGI("Mod Loader initialized successfully");
}

/**
 * Get current memory configuration
 */
size_t GetExtendedHeapSize() {
    return g_extendedHeapSize;
}

/**
 * Check if high memory mode is enabled
 */
bool IsHighMemoryModeEnabled() {
    return g_highMemoryMode;
}
