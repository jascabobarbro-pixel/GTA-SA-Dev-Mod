/**
 * GTA SA Dev Mod - Script Runner Header
 */

#ifndef SCRIPT_RUNNER_H
#define SCRIPT_RUNNER_H

#include <stddef.h>

/**
 * Initialize the script runner
 * @param cleoDir Directory containing CLEO scripts
 */
void InitScriptRunner(const char* cleoDir);

/**
 * Execute a script file
 * @param path Full path to the script file
 * @return true if successful
 */
bool ExecuteScriptFile(const char* path);

/**
 * Stop a running script
 * @param path Full path to the script file
 * @return true if script was stopped
 */
bool StopScript(const char* path);

/**
 * Enable or disable a script
 * @param path Full path to the script file
 * @param enabled Enable state
 */
void SetScriptEnabled(const char* path, bool enabled);

/**
 * Get total script count
 * @return Number of indexed scripts
 */
size_t GetScriptCount();

/**
 * Get running script count
 * @return Number of running scripts
 */
size_t GetRunningScriptCount();

/**
 * Rescan scripts directory for new files
 */
void RescanScripts();

#endif // SCRIPT_RUNNER_H
