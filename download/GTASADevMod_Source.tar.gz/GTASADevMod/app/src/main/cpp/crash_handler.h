/**
 * GTA SA Dev Mod - Crash Handler Header
 */

#ifndef CRASH_HANDLER_H
#define CRASH_HANDLER_H

/**
 * Initialize the native crash handler
 * @param logDir Directory to save crash logs
 */
void InitCrashHandler(const char* logDir);

#endif // CRASH_HANDLER_H
