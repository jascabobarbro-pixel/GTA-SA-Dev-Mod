/**
 * GTA SA Dev Mod - Texture Manager
 * 
 * Manages automatic loading of TXD and IMG texture files.
 * Features:
 * - Recursive scanning of texture directories
 * - Automatic indexing without manual renaming
 * - Memory-efficient texture loading
 */

#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <dirent.h>
#include <sys/stat.h>
#include <android/log.h>

#include "texture_manager.h"

#define LOG_TAG "TextureManager-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Texture info structure
struct TextureInfo {
    std::string name;
    std::string path;
    std::string extension;
    size_t size;
    bool loaded;
};

// Global state
static std::string g_texturesDir;
static std::map<std::string, TextureInfo> g_textures;
static bool g_initialized = false;

// Supported extensions
static const char* SUPPORTED_EXTENSIONS[] = {".txd", ".img", nullptr};

/**
 * Check if file has supported texture extension
 */
static bool isSupportedExtension(const std::string& ext) {
    for (int i = 0; SUPPORTED_EXTENSIONS[i] != nullptr; i++) {
        if (strcasecmp(ext.c_str(), SUPPORTED_EXTENSIONS[i]) == 0) {
            return true;
        }
    }
    return false;
}

/**
 * Recursively scan directory for texture files
 */
static void scanDirectory(const std::string& dirPath, bool recursive) {
    DIR* dir = opendir(dirPath.c_str());
    if (!dir) {
        LOGE("Failed to open directory: %s", dirPath.c_str());
        return;
    }
    
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        
        // Skip . and ..
        if (name == "." || name == "..") {
            continue;
        }
        
        std::string fullPath = dirPath + "/" + name;
        struct stat statbuf;
        
        if (stat(fullPath.c_str(), &statbuf) == 0) {
            if (S_ISDIR(statbuf.st_mode) && recursive) {
                // Recursively scan subdirectory
                scanDirectory(fullPath, true);
            } else if (S_ISREG(statbuf.st_mode)) {
                // Check extension
                size_t dotPos = name.find_last_of('.');
                if (dotPos != std::string::npos) {
                    std::string ext = name.substr(dotPos);
                    if (isSupportedExtension(ext)) {
                        TextureInfo info;
                        info.name = name.substr(0, dotPos);
                        info.path = fullPath;
                        info.extension = ext;
                        info.size = statbuf.st_size;
                        info.loaded = false;
                        
                        g_textures[fullPath] = info;
                        LOGI("Found texture: %s (%zu bytes)", name.c_str(), info.size);
                    }
                }
            }
        }
    }
    
    closedir(dir);
}

/**
 * Initialize texture manager
 */
void InitTextureManager(const char* workingDir) {
    if (g_initialized) {
        return;
    }
    
    LOGI("Initializing Texture Manager");
    
    g_texturesDir = std::string(workingDir) + "/textures";
    
    // Create textures directory if needed
    mkdir(g_texturesDir.c_str(), 0777);
    
    // Scan for texture files
    scanDirectory(g_texturesDir, true);
    
    LOGI("Texture Manager initialized. Found %zu texture files", g_textures.size());
    g_initialized = true;
}

/**
 * Load a texture file
 */
bool LoadTextureFile(const char* path) {
    auto it = g_textures.find(path);
    if (it == g_textures.end()) {
        // Not in index, check if file exists
        struct stat statbuf;
        if (stat(path, &statbuf) != 0) {
            LOGE("Texture file not found: %s", path);
            return false;
        }
        
        // Add to index
        TextureInfo info;
        info.path = path;
        info.loaded = true;
        g_textures[path] = info;
    }
    
    // Mark as loaded
    g_textures[path].loaded = true;
    LOGI("Loaded texture: %s", path);
    
    return true;
}

/**
 * Get texture index
 */
size_t GetTextureCount() {
    return g_textures.size();
}

/**
 * Get loaded texture count
 */
size_t GetLoadedTextureCount() {
    size_t count = 0;
    for (const auto& pair : g_textures) {
        if (pair.second.loaded) count++;
    }
    return count;
}

/**
 * Scan for new textures
 */
void RescanTextures() {
    g_textures.clear();
    scanDirectory(g_texturesDir, true);
    LOGI("Rescanned textures. Found %zu files", g_textures.size());
}
