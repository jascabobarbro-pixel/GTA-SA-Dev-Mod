/**
 * GTA SA Dev Mod - Texture Manager Header
 */

#ifndef TEXTURE_MANAGER_H
#define TEXTURE_MANAGER_H

#include <stddef.h>

/**
 * Initialize the texture manager
 * @param workingDir Working directory containing textures folder
 */
void InitTextureManager(const char* workingDir);

/**
 * Load a texture file
 * @param path Full path to the texture file
 * @return true if successful
 */
bool LoadTextureFile(const char* path);

/**
 * Get total texture count
 * @return Number of indexed textures
 */
size_t GetTextureCount();

/**
 * Get loaded texture count
 * @return Number of loaded textures
 */
size_t GetLoadedTextureCount();

/**
 * Rescan textures directory for new files
 */
void RescanTextures();

#endif // TEXTURE_MANAGER_H
