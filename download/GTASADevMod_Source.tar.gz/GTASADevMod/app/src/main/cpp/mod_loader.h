/**
 * GTA SA Dev Mod - Mod Loader Header
 */

#ifndef MOD_LOADER_H
#define MOD_LOADER_H

#include <stddef.h>

/**
 * Initialize the mod loader
 * @param highMemMode Enable high memory mode for heavy mods
 * @param maxHeapMB Maximum heap size in megabytes
 */
void InitModLoader(bool highMemMode, int maxHeapMB);

/**
 * Get extended heap size
 * @return Extended heap size in bytes
 */
size_t GetExtendedHeapSize();

/**
 * Check if high memory mode is enabled
 * @return true if high memory mode is enabled
 */
bool IsHighMemoryModeEnabled();

#endif // MOD_LOADER_H
