/**
 * GTA SA Dev Mod - Script Runner
 * 
 * Executes CLEO scripts (.cs, .scm) for GTA SA Android.
 * Provides a script execution environment for mod functionality.
 */

#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <dirent.h>
#include <sys/stat.h>
#include <android/log.h>

#include "script_runner.h"

#define LOG_TAG "ScriptRunner-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Script info structure
struct ScriptInfo {
    std::string name;
    std::string path;
    std::string extension;
    size_t size;
    bool enabled;
    bool running;
};

// Global state
static std::string g_cleoDir;
static std::map<std::string, ScriptInfo> g_scripts;
static bool g_initialized = false;

// Supported extensions
static const char* SUPPORTED_EXTENSIONS[] = {".cs", ".scm", ".cleo", nullptr};

/**
 * Check if file has supported script extension
 */
static bool isSupportedExtension(const std::string& ext) {
    for (int i = 0; SUPPORTED_EXTENSIONS[i] != nullptr; i++) {
        if (strcasecmp(ext.c_str(), SUPPORTED_EXTENSIONS[i]) == 0) {
            return true;
        }
    }
    return false;
}

/**
 * Scan CLEO directory for scripts
 */
static void scanCleoDirectory(const std::string& dirPath) {
    DIR* dir = opendir(dirPath.c_str());
    if (!dir) {
        LOGE("Failed to open CLEO directory: %s", dirPath.c_str());
        return;
    }
    
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        
        // Skip . and ..
        if (name == "." || name == "..") {
            continue;
        }
        
        std::string fullPath = dirPath + "/" + name;
        struct stat statbuf;
        
        if (stat(fullPath.c_str(), &statbuf) == 0 && S_ISREG(statbuf.st_mode)) {
            // Check extension
            size_t dotPos = name.find_last_of('.');
            if (dotPos != std::string::npos) {
                std::string ext = name.substr(dotPos);
                if (isSupportedExtension(ext)) {
                    ScriptInfo info;
                    info.name = name.substr(0, dotPos);
                    info.path = fullPath;
                    info.extension = ext;
                    info.size = statbuf.st_size;
                    info.enabled = true;
                    info.running = false;
                    
                    g_scripts[fullPath] = info;
                    LOGI("Found script: %s (%zu bytes)", name.c_str(), info.size);
                }
            }
        }
    }
    
    closedir(dir);
}

/**
 * Initialize script runner
 */
void InitScriptRunner(const char* cleoDir) {
    if (g_initialized) {
        return;
    }
    
    LOGI("Initializing Script Runner");
    
    g_cleoDir = cleoDir ? cleoDir : "/sdcard/GTA_SA_Dev/cleo";
    
    // Create CLEO directory if needed
    mkdir(g_cleoDir.c_str(), 0777);
    
    // Scan for scripts
    scanCleoDirectory(g_cleoDir);
    
    LOGI("Script Runner initialized. Found %zu scripts", g_scripts.size());
    g_initialized = true;
}

/**
 * Execute a script file
 * 
 * This function handles CLEO script execution.
 * In a real implementation, this would interface with the game's script engine.
 */
bool ExecuteScriptFile(const char* path) {
    auto it = g_scripts.find(path);
    if (it == g_scripts.end()) {
        // Not in index, check if file exists
        struct stat statbuf;
        if (stat(path, &statbuf) != 0) {
            LOGE("Script file not found: %s", path);
            return false;
        }
        
        // Add to index
        ScriptInfo info;
        info.path = path;
        info.enabled = true;
        g_scripts[path] = info;
    }
    
    ScriptInfo& script = g_scripts[path];
    
    if (!script.enabled) {
        LOGI("Script is disabled: %s", path);
        return false;
    }
    
    if (script.running) {
        LOGI("Script already running: %s", path);
        return true;
    }
    
    // Read script header for validation
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        LOGE("Failed to open script: %s", path);
        return false;
    }
    
    // Read first bytes for validation
    char header[4];
    file.read(header, sizeof(header));
    file.close();
    
    // Validate script format
    // CLEO scripts typically start with specific magic bytes
    // This is a placeholder for actual validation logic
    
    LOGI("Executing script: %s", path);
    script.running = true;
    
    // In a real implementation, this would:
    // 1. Parse the script bytecode
    // 2. Set up the execution context
    // 3. Register script opcodes
    // 4. Start the script thread
    
    return true;
}

/**
 * Stop a running script
 */
bool StopScript(const char* path) {
    auto it = g_scripts.find(path);
    if (it == g_scripts.end()) {
        return false;
    }
    
    if (it->second.running) {
        LOGI("Stopping script: %s", path);
        it->second.running = false;
        return true;
    }
    
    return false;
}

/**
 * Enable/disable a script
 */
void SetScriptEnabled(const char* path, bool enabled) {
    auto it = g_scripts.find(path);
    if (it != g_scripts.end()) {
        it->second.enabled = enabled;
        LOGI("Script %s: %s", path, enabled ? "enabled" : "disabled");
    }
}

/**
 * Get script count
 */
size_t GetScriptCount() {
    return g_scripts.size();
}

/**
 * Get running script count
 */
size_t GetRunningScriptCount() {
    size_t count = 0;
    for (const auto& pair : g_scripts) {
        if (pair.second.running) count++;
    }
    return count;
}

/**
 * Rescan scripts directory
 */
void RescanScripts() {
    g_scripts.clear();
    scanCleoDirectory(g_cleoDir);
    LOGI("Rescanned scripts. Found %zu files", g_scripts.size());
}
