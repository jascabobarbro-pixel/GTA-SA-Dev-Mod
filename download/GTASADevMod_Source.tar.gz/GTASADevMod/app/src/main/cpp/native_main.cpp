/**
 * GTA SA Dev Mod - Native Entry Point
 * 
 * This is the main native entry point for the GTA SA Dev Mod library.
 * It initializes all native components and bridges Java/Kotlin code with C++.
 */

#include <jni.h>
#include <string>
#include <android/log.h>
#include <android/logbuffer.h>

#define LOG_TAG "GTASADevMod-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

// Forward declarations
extern bool g_highMemoryMode;
extern int g_maxHeapSizeMB;
extern std::string g_workingDir;
extern std::string g_logDir;

// External functions from other modules
extern void InitCrashHandler(const char* logDir);
extern void InitModLoader(bool highMemMode, int maxHeapMB);
extern void InitTextureManager(const char* workingDir);
extern void InitScriptRunner(const char* cleoDir);
extern bool LoadTextureFile(const char* path);
extern bool ExecuteScriptFile(const char* path);

// Global state
bool g_highMemoryMode = false;
int g_maxHeapSizeMB = 512;
std::string g_workingDir;
std::string g_logDir;

/**
 * Initialize native components
 * Called from GTASADevApplication.loadNativeLibrary()
 */
extern "C" JNIEXPORT void JNICALL
Java_com_gtasa_devmod_GTASADevApplication_nativeInitialize(
    JNIEnv* env,
    jobject /* this */,
    jstring abi,
    jboolean is64Bit,
    jstring workingDir,
    jstring logDir
) {
    const char* abiStr = env->GetStringUTFChars(abi, nullptr);
    const char* workingDirStr = env->GetStringUTFChars(workingDir, nullptr);
    const char* logDirStr = env->GetStringUTFChars(logDir, nullptr);
    
    LOGI("Initializing GTA SA Dev Mod Native Library");
    LOGI("ABI: %s, 64-bit: %s", abiStr, is64Bit ? "true" : "false");
    LOGI("Working Dir: %s", workingDirStr);
    LOGI("Log Dir: %s", logDirStr);
    
    // Store global paths
    g_workingDir = workingDirStr;
    g_logDir = logDirStr;
    
    // Initialize crash handler first
    InitCrashHandler(logDirStr);
    LOGI("Crash handler initialized");
    
    // Initialize mod loader
    InitModLoader(g_highMemoryMode, g_maxHeapSizeMB);
    LOGI("Mod loader initialized");
    
    // Initialize texture manager
    InitTextureManager(workingDirStr);
    LOGI("Texture manager initialized");
    
    // Initialize script runner
    std::string cleoDir = workingDirStr + std::string("/cleo");
    InitScriptRunner(cleoDir.c_str());
    LOGI("Script runner initialized");
    
    env->ReleaseStringUTFChars(abi, abiStr);
    env->ReleaseStringUTFChars(workingDir, workingDirStr);
    env->ReleaseStringUTFChars(logDir, logDirStr);
    
    LOGI("GTA SA Dev Mod Native Library initialized successfully");
}

/**
 * Set memory configuration for heavy mods
 */
extern "C" JNIEXPORT void JNICALL
Java_com_gtasa_devmod_modloader_ModLoaderManager_setMemoryConfig(
    JNIEnv* env,
    jobject /* this */,
    jboolean highMemMode,
    jint maxHeapMB
) {
    g_highMemoryMode = highMemMode;
    g_maxHeapSizeMB = maxHeapMB;
    
    LOGI("Memory config set: HighMemMode=%s, MaxHeap=%dMB", 
         highMemMode ? "true" : "false", maxHeapMB);
    
    // Re-initialize mod loader with new memory settings
    InitModLoader(g_highMemoryMode, g_maxHeapSizeMB);
}

/**
 * Load a texture file
 */
extern "C" JNIEXPORT jboolean JNICALL
Java_com_gtasa_devmod_modloader_ModLoaderManager_loadTextureFile(
    JNIEnv* env,
    jobject /* this */,
    jstring path
) {
    const char* pathStr = env->GetStringUTFChars(path, nullptr);
    bool result = LoadTextureFile(pathStr);
    env->ReleaseStringUTFChars(path, pathStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

/**
 * Execute a script file
 */
extern "C" JNIEXPORT jboolean JNICALL
Java_com_gtasa_devmod_modloader_ModLoaderManager_executeScriptFile(
    JNIEnv* env,
    jobject /* this */,
    jstring path
) {
    const char* pathStr = env->GetStringUTFChars(path, nullptr);
    bool result = ExecuteScriptFile(pathStr);
    env->ReleaseStringUTFChars(path, pathStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

/**
 * Initialize native crash handler (called from CrashHandler)
 */
extern "C" JNIEXPORT void JNICALL
Java_com_gtasa_devmod_crash_CrashHandler_initNativeCrashHandler(
    JNIEnv* env,
    jobject /* this */,
    jstring logDir
) {
    const char* logDirStr = env->GetStringUTFChars(logDir, nullptr);
    InitCrashHandler(logDirStr);
    env->ReleaseStringUTFChars(logDir, logDirStr);
}

/**
 * Notify native side about Java crash
 */
extern "C" JNIEXPORT void JNICALL
Java_com_gtasa_devmod_crash_CrashHandler_onJavaCrash(
    JNIEnv* env,
    jobject /* this */,
    jstring exceptionClass,
    jstring message
) {
    const char* classStr = env->GetStringUTFChars(exceptionClass, nullptr);
    const char* msgStr = env->GetStringUTFChars(message, nullptr);
    
    LOGE("Java crash detected: %s - %s", classStr, msgStr);
    
    // Native side cleanup if needed
    // This is called before the app terminates
    
    env->ReleaseStringUTFChars(exceptionClass, classStr);
    env->ReleaseStringUTFChars(message, msgStr);
}

/**
 * Library initialization on load
 */
__attribute__((constructor))
void onLibraryLoad() {
    LOGI("GTA SA Dev Mod Native Library loaded");
}

/**
 * Library cleanup on unload
 */
__attribute__((destructor))
void onLibraryUnload() {
    LOGI("GTA SA Dev Mod Native Library unloading");
}
