/**
 * GTA SA Dev Mod - Native Crash Handler
 * 
 * Advanced crash handling for native C++ code with:
 * - Signal handlers for SIGSEGV, SIGABRT, SIGFPE, SIGBUS, SIGILL
 * - Timestamped crash log files
 * - Stack trace dumping
 * - Register state logging
 * - Memory state at crash time
 */

#include <jni.h>
#include <string>
#include <cstring>
#include <fstream>
#include <sstream>
#include <ctime>
#include <csignal>
#include <cstdlib>
#include <unistd.h>
#include <dlfcn.h>
#include <pthread.h>
#include <ucontext.h>
#include <android/log.h>
#include <sys/stat.h>

#include "crash_handler.h"

#define LOG_TAG "CrashHandler-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Global state
static std::string g_logDirectory;
static bool g_crashHandlerInitialized = false;
static struct sigaction g_oldSigActions[5];
static bool g_hasCrashed = false;

// Signal names
static const char* getSignalName(int sig) {
    switch (sig) {
        case SIGSEGV: return "SIGSEGV";
        case SIGABRT: return "SIGABRT";
        case SIGFPE: return "SIGFPE";
        case SIGBUS: return "SIGBUS";
        case SIGILL: return "SIGILL";
        default: return "UNKNOWN";
    }
}

// Signal descriptions
static const char* getSignalDescription(int sig, int code) {
    switch (sig) {
        case SIGSEGV:
            switch (code) {
                case SEGV_MAPERR: return "Address not mapped to object";
                case SEGV_ACCERR: return "Invalid permissions for mapped object";
                default: return "Segmentation fault";
            }
        case SIGABRT:
            return "Abort signal (usually from abort() call)";
        case SIGFPE:
            switch (code) {
                case FPE_INTDIV: return "Integer divide by zero";
                case FPE_INTOVF: return "Integer overflow";
                case FPE_FLTDIV: return "Floating point divide by zero";
                case FPE_FLTOVF: return "Floating point overflow";
                case FPE_FLTUND: return "Floating point underflow";
                case FPE_FLTRES: return "Floating point inexact result";
                case FPE_FLTINV: return "Invalid floating point operation";
                default: return "Floating point exception";
            }
        case SIGBUS:
            switch (code) {
                case BUS_ADRALN: return "Invalid address alignment";
                case BUS_ADRERR: return "Non-existent physical address";
                case BUS_OBJERR: return "Object specific hardware error";
                default: return "Bus error";
            }
        case SIGILL:
            switch (code) {
                case ILL_ILLOPC: return "Illegal opcode";
                case ILL_ILLOPN: return "Illegal operand";
                case ILL_ILLADR: return "Illegal addressing mode";
                case ILL_ILLTRP: return "Illegal trap";
                case ILL_PRVOPC: return "Privileged opcode";
                case ILL_PRVREG: return "Privileged register";
                case ILL_COPROC: return "Coprocessor error";
                case ILL_BADSTK: return "Internal stack error";
                default: return "Illegal instruction";
            }
        default:
            return "Unknown signal";
    }
}

// Get current timestamp string
static std::string getTimestamp() {
    time_t now = time(nullptr);
    struct tm* tm_info = localtime(&now);
    char buffer[32];
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", tm_info);
    return std::string(buffer);
}

// Get formatted date-time string
static std::string getDateTimeString() {
    time_t now = time(nullptr);
    struct tm* tm_info = localtime(&now);
    char buffer[64];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_info);
    return std::string(buffer);
}

// Generate crash log filename
static std::string generateCrashLogPath() {
    return g_logDirectory + "/crash_log_" + getTimestamp() + ".txt";
}

// Get library name from address
static std::string getLibraryName(void* addr) {
    Dl_info info;
    if (dladdr(addr, &info) && info.dli_fname) {
        const char* fname = strrchr(info.dli_fname, '/');
        return fname ? std::string(fname + 1) : std::string(info.dli_fname);
    }
    return "unknown";
}

// Get symbol name from address
static std::string getSymbolName(void* addr) {
    Dl_info info;
    if (dladdr(addr, &info) && info.dli_sname) {
        return std::string(info.dli_sname);
    }
    return "";
}

// Get relative address in library
static uintptr_t getRelativeAddress(void* addr) {
    Dl_info info;
    if (dladdr(addr, &info)) {
        return (uintptr_t)addr - (uintptr_t)info.dli_fbase;
    }
    return (uintptr_t)addr;
}

// Format hex address
static std::string formatHex(uintptr_t addr) {
    char buffer[20];
    snprintf(buffer, sizeof(buffer), "0x%lX", (unsigned long)addr);
    return std::string(buffer);
}

// Write crash log file
static void writeCrashLog(int sig, siginfo_t* si, void* uc) {
    // Prevent recursive crashes
    if (g_hasCrashed) {
        _exit(1);
    }
    g_hasCrashed = true;
    
    // Create log directory if needed
    mkdir(g_logDirectory.c_str(), 0777);
    
    std::string logPath = generateCrashLogPath();
    std::ofstream log(logPath, std::ios::out | std::ios::trunc);
    
    if (!log.is_open()) {
        LOGE("Failed to open crash log file: %s", logPath.c_str());
        return;
    }
    
    // Header
    log << "============================================================\n";
    log << "GTA SA DEV MOD - NATIVE CRASH LOG\n";
    log << "Generated: " << getDateTimeString() << "\n";
    log << "============================================================\n\n";
    
    // Signal info
    log << "--- Signal Information ---\n";
    log << "Signal: " << getSignalName(sig) << " (" << sig << ")\n";
    log << "Code: " << si->si_code << "\n";
    log << "Description: " << getSignalDescription(sig, si->si_code) << "\n";
    log << "Fault Address: " << formatHex((uintptr_t)si->si_addr) << "\n";
    log << "\n";
    
    // Context info
    ucontext_t* ucontext = (ucontext_t*)uc;
    mcontext_t* mcontext = &ucontext->uc_mcontext;
    
#if defined(__aarch64__)
    // ARM64 registers
    uintptr_t pc = mcontext->pc;
    uintptr_t sp = mcontext->sp;
    
    log << "--- ARM64 Registers ---\n";
    log << "PC: " << formatHex(pc) << " (" << getLibraryName((void*)pc) 
        << " + " << formatHex(getRelativeAddress((void*)pc)) << ")\n";
    log << "SP: " << formatHex(sp) << "\n";
    log << "LR: " << formatHex(mcontext->regs[30]) << "\n";
    log << "FP: " << formatHex(mcontext->regs[29]) << "\n";
    
    // General purpose registers
    log << "\nGeneral Purpose Registers:\n";
    for (int i = 0; i < 31; i++) {
        log << "X" << i << ": " << formatHex(mcontext->regs[i]);
        if ((i + 1) % 4 == 0) log << "\n";
        else log << "  ";
    }
    log << "\n";
    
#elif defined(__arm__)
    // ARM32 registers
    uintptr_t pc = mcontext->arm_pc;
    uintptr_t sp = mcontext->arm_sp;
    
    log << "--- ARM32 Registers ---\n";
    log << "PC: " << formatHex(pc) << " (" << getLibraryName((void*)pc) 
        << " + " << formatHex(getRelativeAddress((void*)pc)) << ")\n";
    log << "SP: " << formatHex(sp) << "\n";
    log << "LR: " << formatHex(mcontext->arm_lr) << "\n";
    log << "FP: " << formatHex(mcontext->arm_fp) << "\n";
    
    // General purpose registers
    log << "\nGeneral Purpose Registers:\n";
    for (int i = 0; i < 16; i++) {
        log << "R" << i << ": " << formatHex((&mcontext->arm_r0)[i]);
        if ((i + 1) % 4 == 0) log << "\n";
        else log << "  ";
    }
    log << "\n";
#endif
    
    // Symbol info
    std::string symbolName = getSymbolName((void*)pc);
    if (!symbolName.empty()) {
        log << "\nSymbol: " << symbolName << "\n";
    }
    
    // Memory state
    log << "\n--- Memory Information ---\n";
    FILE* meminfo = fopen("/proc/self/status", "r");
    if (meminfo) {
        char line[256];
        while (fgets(line, sizeof(line), meminfo)) {
            if (strncmp(line, "Vm", 2) == 0) {
                log << line;
            }
        }
        fclose(meminfo);
    }
    
    // Loaded libraries
    log << "\n--- Loaded Libraries ---\n";
    FILE* maps = fopen("/proc/self/maps", "r");
    if (maps) {
        char line[512];
        while (fgets(line, sizeof(line), maps)) {
            if (strstr(line, ".so") || strstr(line, "gtasa")) {
                log << line;
            }
        }
        fclose(maps);
    }
    
    // Footer
    log << "\n============================================================\n";
    log << "END OF NATIVE CRASH LOG\n";
    log << "Log saved to: " << logPath << "\n";
    log << "Please report this crash to the developers\n";
    log << "============================================================\n";
    
    log.close();
    
    LOGE("Crash log saved to: %s", logPath.c_str());
}

// Signal handler
static void signalHandler(int sig, siginfo_t* si, void* uc) {
    LOGE("Native crash detected: %s", getSignalName(sig));
    
    // Write crash log
    writeCrashLog(sig, si, uc);
    
    // Call old handler if exists
    int sigIndex = -1;
    switch (sig) {
        case SIGSEGV: sigIndex = 0; break;
        case SIGABRT: sigIndex = 1; break;
        case SIGFPE: sigIndex = 2; break;
        case SIGBUS: sigIndex = 3; break;
        case SIGILL: sigIndex = 4; break;
    }
    
    if (sigIndex >= 0 && g_oldSigActions[sigIndex].sa_sigaction != nullptr) {
        g_oldSigActions[sigIndex].sa_sigaction(sig, si, uc);
    } else {
        // Default termination
        signal(sig, SIG_DFL);
        raise(sig);
    }
}

// Install signal handler
static void installSignalHandler(int sig, int index) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = signalHandler;
    sa.sa_flags = SA_SIGINFO | SA_RESETHAND;
    sigemptyset(&sa.sa_mask);
    
    sigaction(sig, &sa, &g_oldSigActions[index]);
}

/**
 * Initialize the crash handler
 */
void InitCrashHandler(const char* logDir) {
    if (g_crashHandlerInitialized) {
        return;
    }
    
    g_logDirectory = logDir ? logDir : "/sdcard/GTA_SA_Dev/logs";
    
    // Create log directory
    mkdir(g_logDirectory.c_str(), 0777);
    
    // Install signal handlers
    installSignalHandler(SIGSEGV, 0);
    installSignalHandler(SIGABRT, 1);
    installSignalHandler(SIGFPE, 2);
    installSignalHandler(SIGBUS, 3);
    installSignalHandler(SIGILL, 4);
    
    g_crashHandlerInitialized = true;
    LOGI("Native crash handler initialized. Log dir: %s", g_logDirectory.c_str());
}
