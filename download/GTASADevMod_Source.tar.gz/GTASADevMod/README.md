# GTA SA Dev Mod - Ultimate Edition

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Android](https://img.shields.io/badge/Android-24%2B-green.svg)](https://developer.android.com)
[![API](https://img.shields.io/badge/API-35%2B-brightgreen.svg)](https://android-arsenal.com/api?level=35)

**Advanced modding environment for GTA San Andreas Android with full Android 15 support.**

## Features

### Core Features

- **Advanced Crash Reporter**
  - Timestamped crash log files (`crash_log_[timestamp].txt`)
  - Both Java and Native C++ crash handling
  - Automatic stack trace dumping
  - Register state logging (ARM32/ARM64)
  - Toast notification on crash detection
  - Logs saved to `Documents/GTA_SA_Dev/Logs/`

- **Android 15 & Scoped Storage Compliance**
  - Full support for Android 11+ scoped storage restrictions
  - MANAGE_EXTERNAL_STORAGE permission handling
  - Unprotected directory support at `/sdcard/GTA_SA_Dev/`
  - No permission issues for mod file operations

- **CPU Architecture Auto-Detection**
  - Automatic detection of ARM64, ARMv7, x86, and x86_64
  - Native library auto-selection based on device ABI
  - Architecture-specific configuration support

- **Auto TXD/Database Detection**
  - Recursive scanning of `/sdcard/GTA_SA_Dev/textures/` folder
  - Automatic indexing of `.txd` and `.img` files
  - No manual renaming required
  - Subdirectory support for organized mod storage

- **Heavy Mod Support Framework**
  - Configurable heap size (256MB - 2GB)
  - High Memory Mode for large map boundaries
  - Memory-optimized texture loading
  - `EnableHighMemMode = true` in settings.ini

- **CLEO Script Support**
  - CLEO script execution environment
  - Support for `.cs`, `.scm`, and `.cleo` formats
  - Script enable/disable management
  - Located in `/sdcard/GTA_SA_Dev/cleo/`

### Developer Tools

- **Script Editor** - Edit and run CLEO scripts directly
- **Texture Viewer** - Browse loaded TXD/IMG files
- **Log Viewer** - View application and crash logs
- **System Report Generator** - Export diagnostic information

## Directory Structure

```
/sdcard/GTA_SA_Dev/
├── textures/        # TXD and IMG texture files
│   └── (subdirectories supported)
├── models/          # DFF and COL model files
├── cleo/            # CLEO scripts (.cs, .scm)
├── configs/         # Configuration files
├── logs/            # Crash and debug logs
└── backups/         # Automatic backups
```

## Building

### Prerequisites

- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 35
- Android NDK 25.2.9519653 or later
- CMake 3.22.1+
- Gradle 8.5+

### Build Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/GTASA-DevMod/GTA-SA-Dev-Mod.git
   cd GTA-SA-Dev-Mod
   ```

2. Open in Android Studio

3. Sync Gradle files

4. Build the APK:
   ```bash
   ./gradlew assembleRelease
   ```

5. Find the APK in `app/build/outputs/apk/release/`

## Configuration

### settings.ini

Located in `/sdcard/GTA_SA_Dev/configs/settings.ini`:

```ini
[Performance]
EnableHighMemMode = true
MaxHeapSizeMB = 512

[Modding]
AutoLoadTXD = true
AutoLoadIMG = true
CLEOEnabled = true

[Graphics]
EnableVSync = true
TextureQuality = 2
DrawDistance = 1.0

[Debug]
DebugMode = false
LogLevel = 2
```

## Compatibility

- **Minimum SDK**: Android 7.0 (API 24)
- **Target SDK**: Android 15 (API 35)
- **Supported ABIs**: arm64-v8a, armeabi-v7a, x86, x86_64

## Permissions

| Permission | Purpose |
|------------|---------|
| `MANAGE_EXTERNAL_STORAGE` | Full file access for mod operations (Android 11+) |
| `READ_EXTERNAL_STORAGE` | Read mod files (Android 10 and below) |
| `WRITE_EXTERNAL_STORAGE` | Write crash logs and backups |
| `INTERNET` | Mod updates and downloads |
| `VIBRATE` | Haptic feedback |
| `POST_NOTIFICATIONS` | Status notifications (Android 13+) |

## Third-Party Libraries

- AndroidX Libraries
- Kotlin Coroutines
- Google Gson

## Credits

- **AML (Android Mod Loader)** - Base mod loading infrastructure
- **CLEO Library** - Script execution support
- All contributors and testers

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Disclaimer

This project is a modding tool and does not contain any copyrighted game assets. Users must own a legitimate copy of GTA San Andreas Android to use this mod. The developers are not responsible for any misuse of this software.

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## Support

- **Issues**: [GitHub Issues](https://github.com/GTASA-DevMod/GTA-SA-Dev-Mod/issues)
- **Discussions**: [GitHub Discussions](https://github.com/GTASA-DevMod/GTA-SA-Dev-Mod/discussions)

---

**GTA SA Dev Mod - Ultimate Edition** © 2024
